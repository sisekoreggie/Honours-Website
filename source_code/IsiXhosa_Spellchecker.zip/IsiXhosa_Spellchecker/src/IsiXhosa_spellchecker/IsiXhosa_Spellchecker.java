/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IsiXhosa_spellchecker;
/**
 *
 * @author Nthabiseng Mashiane
 */

public class IsiXhosa_Spellchecker {

    public static void main(String[] args){
        
        //Spellchecker.main(args);
        AccuracyTest ac = new AccuracyTest();
        ac.main(args);
    }

}
