# Morphological-Analyser
IsiXhosa Morphological Analyser

1. Download and Install the SFST (Stuttgart Finite-State Transducer) tool for linux at 
   http://www.cis.uni-muenchen.de/~schmid/tools/SFST/
2. To compile the intergrated_system.fst: fst-compiler intergrated_system.fst intergrated_system.a 
   compile all .fst files just to be on the safe side.
   then to run: fst-mor intergrated_system.a => this allows you to enter single words to the transducer

Us the speller.java file which is the GUI developed in java Swing to run the spellchecker and perform any taks that you would like.
